# app/utils/email_alert.py
import logging
import os
from smtplib import SMTP
from email.message import EmailMessage

logger = logging.getLogger("alerts")

SMTP_HOST = os.environ.get("SMTP_HOST")
SMTP_PORT = int(os.environ.get("SMTP_PORT", 587))
SMTP_USER = os.environ.get("SMTP_USER")
SMTP_PASS = os.environ.get("SMTP_PASS")
ALERT_TO = os.environ.get("ALERT_TO", "oncall@example.com")

def send_alert_email(to: str, subject: str, body: str):
    """
    Try SMTP if env is configured; otherwise fallback to logging the alert.
    """
    if SMTP_HOST and SMTP_USER and SMTP_PASS:
        try:
            msg = EmailMessage()
            msg.set_content(body)
            msg["Subject"] = subject
            msg["From"] = SMTP_USER
            msg["To"] = to

            with SMTP(host=SMTP_HOST, port=SMTP_PORT) as s:
                s.starttls()
                s.login(SMTP_USER, SMTP_PASS)
                s.send_message(msg)
            logger.warning("Sent alert to %s subj=%s", to, subject)
            return
        except Exception as e:
            logger.exception("SMTP send failed: %s", e)

    # fallback
    logger.warning("ALERT (fallback) -> to=%s subject=%s body=%s", to, subject, body)
