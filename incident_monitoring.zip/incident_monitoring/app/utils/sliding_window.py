# app/utils/sliding_window.py
"""
A tiny helper to aggregate recent events for sliding-window checks.
This module uses DB queries instead of keeping huge in-memory state so it is simple and robust across restarts.
"""
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from app import models

def count_events_in_window(db: Session, metric: str, source: str, window_seconds: int):
    cutoff = datetime.utcnow() - timedelta(seconds=window_seconds)
    q = db.query(models.Event).filter(
        models.Event.metric == metric,
        models.Event.source == source,
        models.Event.created_at >= cutoff
    )
    return q.count()

def avg_value_in_window(db: Session, metric: str, source: str, window_seconds: int):
    cutoff = datetime.utcnow() - timedelta(seconds=window_seconds)
    q = db.query(models.Event).filter(
        models.Event.metric == metric,
        models.Event.source == source,
        models.Event.created_at >= cutoff
    )
    values = [e.value for e in q.all()]
    if not values:
        return None
    return sum(values) / len(values)
