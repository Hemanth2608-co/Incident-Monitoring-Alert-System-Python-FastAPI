# app/utils/anomaly_detector.py
from typing import Dict
from app.utils.sliding_window import count_events_in_window, avg_value_in_window

# Base thresholds (can be extended or moved to DB/config)
THRESHOLDS: Dict[str, Dict] = {
    "cpu": {"critical": 90.0, "warning": 75.0},
    "memory": {"critical": 90.0, "warning": 75.0},
    "http_5xx": {"critical": 50.0, "warning": 10.0},
    "packet_loss": {"critical": 20.0, "warning": 5.0},
}

def evaluate_simple(metric: str, value: float) -> str:
    cfg = THRESHOLDS.get(metric)
    if not cfg:
        return "info"
    if value >= cfg["critical"]:
        return "critical"
    if value >= cfg["warning"]:
        return "warning"
    return "info"

def evaluate_with_window(db, metric: str, source: str, value: float) -> str:
    """
    Combine simple threshold check with sliding-window rules.
    Examples:
      - If http_5xx percent average over last 60s > warning -> warning/critical
      - If number of "cpu" spikes in last 120s > 3 -> escalate
    """
    # First, baseline
    base = evaluate_simple(metric, value)
    if base == "critical":
        return "critical"

    # window-based heuristics
    if metric == "http_5xx":
        avg = avg_value_in_window(db, metric, source, window_seconds=60)
        if avg is not None:
            if avg >= THRESHOLDS[metric]["critical"]:
                return "critical"
            if avg >= THRESHOLDS[metric]["warning"]:
                return "warning"
        return base

    if metric == "cpu":
        spikes = count_events_in_window(db, "cpu", source, window_seconds=120)
        # define spike as value >= warning threshold — events table will contain raw values
        # if there are many spammy high events, escalate
        if spikes >= 5 and value >= THRESHOLDS[metric]["warning"]:
            return "critical"
        return base

    return base
