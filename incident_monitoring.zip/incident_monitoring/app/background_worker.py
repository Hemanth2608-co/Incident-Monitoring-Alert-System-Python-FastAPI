# app/background_worker.py
import threading
import time
from sqlalchemy.orm import Session
from app.db import SessionLocal
from app import models
from app.utils.anomaly_detector import evaluate_with_window
from app.utils.email_alert import send_alert_email
from datetime import datetime

SCAN_INTERVAL = int(__import__('os').environ.get('SCAN_INTERVAL', 5))

def process_event(ev, db: Session):
    # Double-check if incident already exists
    existing = db.query(models.Incident).filter(models.Incident.event_id == ev.id).first()
    if existing:
        return
    # Evaluate severity using DB-aware detector
    severity = evaluate_with_window(db, ev.metric, ev.source, ev.value)
    if severity in ("warning", "critical"):
        title = f"{severity.upper()}: {ev.metric} on {ev.source}"
        desc = f"Value {ev.value} exceeded {severity} threshold for metric {ev.metric}."
        inc = models.Incident(
            event_id=ev.id,
            title=title,
            description=desc,
            source=ev.source,
            metric=ev.metric,
            value=ev.value,
        )
        db.add(inc)
        db.commit()
        db.refresh(inc)
        send_alert_email(to=None, subject=title, body=f"{desc}\nEvent raw: {ev.raw or 'n/a'}\nIncident id: {inc.id}")

def scan_and_create_incidents():
    db: Session = SessionLocal()
    try:
        # Find recent events not older than 10 minutes
        recent_events = db.query(models.Event).order_by(models.Event.created_at.desc()).limit(500).all()
        for ev in recent_events:
            process_event(ev, db)
    except Exception as e:
        print("Worker error:", e)
    finally:
        db.close()

def start_background_worker(app):
    def loop():
        while True:
            try:
                scan_and_create_incidents()
            except Exception as e:
                print("Worker main loop error:", e)
            time.sleep(SCAN_INTERVAL)
    t = threading.Thread(target=loop, daemon=True)
    t.start()
    app.state.worker_thread = t
