# app/models.py
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text
from sqlalchemy.sql import func
from app.db import Base

class Event(Base):
    __tablename__ = "events"
    id = Column(Integer, primary_key=True, index=True)
    source = Column(String, index=True)
    metric = Column(String, index=True)
    value = Column(Float)
    severity = Column(String, default="info")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    raw = Column(Text)

class Incident(Base):
    __tablename__ = "incidents"
    id = Column(Integer, primary_key=True, index=True)
    event_id = Column(Integer, index=True)
    title = Column(String, index=True)
    description = Column(Text)
    source = Column(String, index=True)
    metric = Column(String, index=True)
    value = Column(Float)
    resolved = Column(Boolean, default=False, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    resolved_at = Column(DateTime(timezone=True), nullable=True)
