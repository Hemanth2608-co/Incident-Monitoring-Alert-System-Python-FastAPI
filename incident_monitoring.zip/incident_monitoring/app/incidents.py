# app/incidents.py
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.db import get_db
from app import models
from app.schemas import EventIn, IncidentOut, EventOut
from app.utils.anomaly_detector import evaluate_with_window
from datetime import datetime

router = APIRouter()

@router.post("/ingest", summary="Ingest an event/log")
def ingest_event(payload: EventIn, db: Session = Depends(get_db)):
    ev = models.Event(
        source=payload.source, metric=payload.metric, value=payload.value, raw=payload.raw
    )
    db.add(ev)
    db.commit()
    db.refresh(ev)

    # Evaluate immediately (fast path) and set severity on event record
    severity = evaluate_with_window(db, payload.metric, payload.source, payload.value)
    ev.severity = severity
    db.commit()

    return {"event_id": ev.id, "status": "ingested", "severity": severity}

@router.get("/events/{event_id}", response_model=EventOut)
def get_event(event_id: int, db: Session = Depends(get_db)):
    ev = db.query(models.Event).filter(models.Event.id == event_id).first()
    if not ev:
        raise HTTPException(404, "Event not found")
    return ev

@router.get("/incidents", response_model=List[IncidentOut], summary="List incidents")
def list_incidents(
    db: Session = Depends(get_db),
    resolved: Optional[bool] = Query(None),
    source: Optional[str] = Query(None),
    metric: Optional[str] = Query(None),
    limit: int = 50,
):
    q = db.query(models.Incident)
    if resolved is not None:
        q = q.filter(models.Incident.resolved == resolved)
    if source:
        q = q.filter(models.Incident.source == source)
    if metric:
        q = q.filter(models.Incident.metric == metric)
    q = q.order_by(models.Incident.created_at.desc()).limit(limit)
    return q.all()

@router.post("/incidents/{incident_id}/resolve", summary="Mark incident resolved")
def resolve_incident(incident_id: int, db: Session = Depends(get_db)):
    inc = db.query(models.Incident).filter(models.Incident.id == incident_id).first()
    if not inc:
        raise HTTPException(status_code=404, detail="Incident not found")
    if inc.resolved:
        return {"status": "already_resolved"}
    inc.resolved = True
    inc.resolved_at = datetime.utcnow()
    db.commit()
    return {"status": "resolved", "incident_id": inc.id}
