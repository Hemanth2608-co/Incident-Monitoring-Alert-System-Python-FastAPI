# app/schemas.py
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class EventIn(BaseModel):
    source: str
    metric: str
    value: float
    raw: Optional[str] = None

class EventOut(BaseModel):
    id: int
    source: str
    metric: str
    value: float
    severity: str
    created_at: datetime
    raw: Optional[str]

    class Config:
        orm_mode = True

class IncidentOut(BaseModel):
    id: int
    event_id: int
    title: str
    description: Optional[str]
    source: str
    metric: str
    value: float
    resolved: bool
    created_at: datetime
    resolved_at: Optional[datetime]

    class Config:
        orm_mode = True
