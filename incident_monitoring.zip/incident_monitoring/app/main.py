# app/main.py
from fastapi import FastAPI
from app.db import engine
from app import models
from app.incidents import router as incidents_router
from app.background_worker import start_background_worker

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Incident Monitoring API", version="0.2")
app.include_router(incidents_router, prefix="/api")

@app.on_event("startup")
def startup_event():
    start_background_worker(app)

@app.get("/")
def root():
    return {"service": "incident-monitoring", "version": "0.2"}
