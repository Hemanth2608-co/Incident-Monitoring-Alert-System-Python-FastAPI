# Incident Alert & Monitoring System (Full Project)

## Overview
A small, real-world-like incident monitoring system that ingests events, performs threshold + sliding-window anomaly detection, creates incidents, and emits alerts.

Tech: Python, FastAPI, SQLAlchemy, Docker.

## Quick start (local)
1. Copy repo files and create a virtualenv:

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

2. Run the app:

```bash
uvicorn app.main:app --reload
```

API endpoints:
- `POST /api/ingest` -> {source, metric, value, raw}
- `GET /api/events/{id}` -> get event
- `GET /api/incidents` -> list incidents
- `POST /api/incidents/{id}/resolve` -> mark resolved

3. In another terminal, run simulator:

```bash
python simulations/simulate_events.py
```

Watch console logs for alert messages. Use `curl` or Postman to call endpoints and show incidents.

## Docker
Build and run with docker-compose:

```bash
docker-compose up --build
```

## Tests
Run unit tests:

```bash
pytest
```

## What to show in an interview
1. Demo: Run simulator -> show no incidents for normal traffic -> trigger a spike -> show incident created and alert in logs -> mark incident resolved.
2. Explain architecture: ingestion API, DB, background worker, pluggable alert adapter, and how you'd scale with a message queue and worker pool.
3. Show code for anomaly detector (threshold + sliding-window) and explain design tradeoffs.

## Extensions
- Add authentication, RBAC, Postgres in production, Redis cache, Prometheus metrics, Grafana dashboard, OpenCV camera ingestion, PagerDuty/Twilio integration.
