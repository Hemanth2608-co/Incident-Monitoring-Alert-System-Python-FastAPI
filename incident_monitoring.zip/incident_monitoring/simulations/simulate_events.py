# simulations/simulate_events.py
"""
Simple event simulator. Run while the API is running to create normal + anomaly traffic.
Usage: python simulations/simulate_events.py
"""
import requests
import time
import random
import os

API = os.environ.get('API_URL', 'http://localhost:8000/api/ingest')

SOURCES = ['web-1', 'web-2', 'db-1', 'api-gw', 'cache-1']
METRICS = ['cpu', 'memory', 'http_5xx', 'packet_loss']

def send_event(source, metric, value):
    payload = {'source': source, 'metric': metric, 'value': value, 'raw': None}
    try:
        r = requests.post(API, json=payload, timeout=2)
        print('sent', payload, '->', r.status_code, r.json())
    except Exception as e:
        print('send error', e)

def normal_traffic():
    src = random.choice(SOURCES)
    m = random.choice(METRICS)
    if m == 'cpu' or m == 'memory':
        val = random.uniform(10, 60)
    elif m == 'http_5xx':
        val = random.uniform(0, 5)
    else:
        val = random.uniform(0, 1)
    send_event(src, m, round(val, 2))

def spike_traffic():
    src = random.choice(SOURCES)
    m = random.choice(METRICS)
    if m == 'cpu' or m == 'memory':
        val = random.uniform(80, 98)
    elif m == 'http_5xx':
        val = random.uniform(30, 90)
    else:
        val = random.uniform(5, 30)
    # send multiple events for spike
    for _ in range(random.randint(3, 10)):
        send_event(src, m, round(val + random.uniform(-2, 2), 2))
        time.sleep(0.2)

if __name__ == '__main__':
    print('Simulator started. CTRL+C to stop.')
    while True:
        # mostly normal, sometimes spike
        if random.random() < 0.08:
            spike_traffic()
        else:
            normal_traffic()
        time.sleep(random.uniform(0.5, 1.5))
