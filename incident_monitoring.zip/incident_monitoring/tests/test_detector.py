# tests/test_detector.py
import tempfile
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.db import Base
from app import models
from app.utils.anomaly_detector import evaluate_simple

def test_thresholds():
    assert evaluate_simple('cpu', 95) == 'critical'
    assert evaluate_simple('cpu', 80) == 'warning'
    assert evaluate_simple('http_5xx', 0) == 'info'
